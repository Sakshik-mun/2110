import os, sys, tempfile
os.environ["DATABASE_URL"] = f"sqlite:///{tempfile.mkdtemp()}/test.db"
os.environ.pop("GEMINI_API_KEY", None)
sys.path.insert(0, os.path.dirname(os.path.dirname(__file__)))

from fastapi.testclient import TestClient  # noqa: E402
from main import app  # noqa: E402

client = TestClient(app)
PROFILE = dict(monthly_income=100000, monthly_expenses=40000, monthly_emi=45000, total_debt=900000,
               credit_limit=200000, credit_used=120000, active_loans=2, missed_payments=1,
               savings=50000, cibil_score=690, goal="Reach 750")


def auth():
    r = client.post("/api/auth/register", json={"name": "Asha", "email": "asha@example.com", "password": "password123"})
    if r.status_code == 409:
        r = client.post("/api/auth/login", json={"email": "asha@example.com", "password": "password123"})
    return {"Authorization": f"Bearer {r.json()['access_token']}"}


def test_register_login_and_protection():
    h = auth()
    assert client.get("/api/auth/me", headers=h).json()["name"] == "Asha"
    assert client.get("/api/profile").status_code == 401
    bad = client.post("/api/auth/login", json={"email": "asha@example.com", "password": "wrongpass1"})
    assert bad.status_code == 401


def test_validation():
    h = auth()
    assert client.put("/api/profile", json={**PROFILE, "cibil_score": 1000}, headers=h).status_code == 422
    assert client.put("/api/profile", json={**PROFILE, "credit_used": 999999}, headers=h).status_code == 422


def test_dashboard_metrics_and_history():
    h = auth()
    assert client.put("/api/profile", json=PROFILE, headers=h).status_code == 200
    client.post("/api/scores", json={"score": 720}, headers=h)
    d = client.get("/api/dashboard", headers=h).json()
    assert d["metrics"]["dti"] == 45.0
    assert d["metrics"]["utilization"] == 60.0
    assert d["improvement"] > 0
    assert len(d["history"]) >= 2


def test_advisor_fallback():
    h = auth()
    client.put("/api/profile", json=PROFILE, headers=h)
    assert "Rule-based" in client.post("/api/advisor/analyze", headers=h).json()["content"]
    assert client.post("/api/advisor/chat", json={"message": "How to improve?"}, headers=h).status_code == 200
