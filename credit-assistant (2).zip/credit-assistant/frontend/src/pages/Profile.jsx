import { useEffect, useState } from "react";
import { api } from "../api";

const FIELDS = [
  ["monthly_income", "Monthly income (₹)"], ["monthly_expenses", "Monthly expenses (₹)"],
  ["monthly_emi", "Total monthly EMI (₹)"], ["total_debt", "Total outstanding debt (₹)"],
  ["credit_limit", "Total credit card limit (₹)"], ["credit_used", "Credit card balance used (₹)"],
  ["active_loans", "Active loans"], ["missed_payments", "Missed payments"],
  ["savings", "Savings (₹)"], ["cibil_score", "Current CIBIL score (300–900)"],
];

export default function Profile() {
  const [f, setF] = useState(null);
  const [msg, setMsg] = useState("");
  const [err, setErr] = useState("");
  useEffect(() => { api("/profile").then(setF).catch((e) => setErr(e.message)); }, []);
  if (!f) return err ? <p className="err">{err}</p> : <p>Loading…</p>;

  const save = async (e) => {
    e.preventDefault(); setMsg(""); setErr("");
    const body = { ...f };
    FIELDS.forEach(([k]) => (body[k] = Number(body[k])));
    try { await api("/profile", { method: "PUT", body }); setMsg("Profile saved"); }
    catch (e2) { setErr(e2.message); }
  };

  return (
    <form onSubmit={save} className="panel">
      <h1>Financial profile</h1>
      <div className="grid">
        {FIELDS.map(([k, label]) => (
          <label key={k}>{label}
            <input type="number" min="0" value={f[k]} onChange={(e) => setF({ ...f, [k]: e.target.value })} required />
          </label>
        ))}
      </div>
      <label>Financial goal
        <input value={f.goal} maxLength={255} placeholder="e.g. Reach a 750 score in 6 months"
          onChange={(e) => setF({ ...f, goal: e.target.value })} />
      </label>
      {err && <p className="err" role="alert">{err}</p>}
      {msg && <p className="up" role="status">{msg}</p>}
      <button className="primary">Save profile</button>
    </form>
  );
}
