import { useEffect, useState } from "react";
import { api } from "../api";

export default function Advisor() {
  const [analysis, setAnalysis] = useState("");
  const [q, setQ] = useState("");
  const [log, setLog] = useState([]);
  const [busy, setBusy] = useState(false);
  const [err, setErr] = useState("");

  useEffect(() => {
    api("/recommendations").then((rows) =>
      setLog(rows.filter((r) => r.kind === "chat").reverse().flatMap((r) => [
        { role: "user", text: r.prompt }, { role: "ai", text: r.content }]))
    ).catch(() => {});
  }, []);

  const run = async (fn) => {
    setBusy(true); setErr("");
    try { await fn(); } catch (e) { setErr(e.message); }
    setBusy(false);
  };

  const analyze = () => run(async () => setAnalysis((await api("/advisor/analyze", { method: "POST" })).content));
  const ask = (e) => {
    e.preventDefault();
    if (!q.trim()) return;
    const msg = q; setQ("");
    run(async () => {
      setLog((l) => [...l, { role: "user", text: msg }]);
      const r = await api("/advisor/chat", { method: "POST", body: { message: msg } });
      setLog((l) => [...l, { role: "ai", text: r.content }]);
    });
  };

  return (
    <>
      <h1>AI advisor</h1>
      <section className="panel">
        <h2>Full credit health analysis</h2>
        <button className="primary" onClick={analyze} disabled={busy}>{busy ? "Working…" : "Analyze my profile"}</button>
        {analysis && <pre className="ai">{analysis}</pre>}
      </section>
      <section className="panel">
        <h2>Ask a question</h2>
        <div className="chat">
          {log.length === 0 && <p>Ask about improving your score, reducing debt, or planning a goal.</p>}
          {log.map((m, i) => <pre key={i} className={`msg ${m.role}`}>{m.text}</pre>)}
        </div>
        <form onSubmit={ask} className="row">
          <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="How can I reduce my utilization?" maxLength={1000} />
          <button className="primary" disabled={busy}>Send</button>
        </form>
      </section>
      {err && <p className="err" role="alert">{err}</p>}
    </>
  );
}
