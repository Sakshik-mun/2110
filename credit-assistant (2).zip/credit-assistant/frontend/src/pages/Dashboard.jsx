import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { PieChart, Pie, Cell, LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { api } from "../api";

const inr = (n) => "₹" + Math.round(n).toLocaleString("en-IN");
const Stat = ({ label, value }) => (
  <div className="stat"><span>{label}</span><b>{value}</b></div>
);

export default function Dashboard() {
  const [d, setD] = useState(null);
  const [err, setErr] = useState("");
  useEffect(() => { api("/dashboard").then(setD).catch((e) => setErr(e.message)); }, []);
  if (err) return <p className="err">{err}</p>;
  if (!d) return <p>Loading…</p>;
  const { metrics: m, profile: p } = d;

  return (
    <>
      <h1>{d.user.name}'s credit health</h1>
      {!p.monthly_income && (
        <p className="note">Your profile is empty. <Link to="/profile">Add your financial details</Link> to see analysis.</p>
      )}

      <section className="hero">
        <div>
          <div className="score">{p.cibil_score}</div>
          <p>CIBIL score · {m.cibil_band}</p>
          <p className={d.improvement >= 0 ? "up" : "down"}>
            {d.improvement >= 0 ? "+" : ""}{d.improvement} points since first record
          </p>
        </div>
        <div>
          <div className="score">{m.health_score}<small>/100</small></div>
          <p>Financial health · {m.health_label}</p>
        </div>
      </section>

      <section className="stats">
        <Stat label="Debt-to-income" value={`${m.dti}%`} />
        <Stat label="Credit utilization" value={`${m.utilization}%`} />
        <Stat label="Savings rate" value={`${m.savings_rate}%`} />
        <Stat label="Active loans" value={p.active_loans} />
        <Stat label="Missed payments" value={p.missed_payments} />
        <Stat label="Savings" value={inr(p.savings)} />
      </section>

      <section className="charts">
        <div className="panel">
          <h2>Score history</h2>
          {d.history.length ? (
            <ResponsiveContainer width="100%" height={240}>
              <LineChart data={d.history}>
                <CartesianGrid strokeDasharray="3 3" stroke="#d9d4c7" />
                <XAxis dataKey="date" fontSize={12} />
                <YAxis domain={[300, 900]} fontSize={12} />
                <Tooltip />
                <Line type="monotone" dataKey="score" stroke="#1b4d3e" strokeWidth={2.5} />
              </LineChart>
            </ResponsiveContainer>
          ) : <p>No scores recorded yet.</p>}
        </div>
        <div className="panel">
          <h2>Credit utilization</h2>
          <ResponsiveContainer width="100%" height={240}>
            <PieChart>
              <Pie data={d.utilization_chart} dataKey="value" nameKey="name" innerRadius={55} outerRadius={90}>
                <Cell fill="#b4432c" /><Cell fill="#1b4d3e" />
              </Pie>
              <Tooltip formatter={(v) => inr(v)} />
            </PieChart>
          </ResponsiveContainer>
        </div>
      </section>

      <section className="panel">
        <h2>Risks to watch</h2>
        {m.risks.length ? <ul>{m.risks.map((r) => <li key={r}>{r}</li>)}</ul> : <p>No major risks detected.</p>}
      </section>

      <section className="panel">
        <h2>Latest AI recommendation</h2>
        {d.latest_recommendation
          ? <pre className="ai">{d.latest_recommendation}</pre>
          : <p>No analysis yet. <Link to="/advisor">Run an AI analysis</Link>.</p>}
      </section>
    </>
  );
}
