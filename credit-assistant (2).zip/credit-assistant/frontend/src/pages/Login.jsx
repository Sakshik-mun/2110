import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { api, setToken } from "../api";

export default function Login() {
  const nav = useNavigate();
  const [mode, setMode] = useState("login");
  const [f, setF] = useState({ name: "", email: "", password: "" });
  const [err, setErr] = useState("");
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const submit = async (e) => {
    e.preventDefault();
    setErr("");
    try {
      const body = mode === "login" ? { email: f.email, password: f.password } : f;
      const { access_token } = await api(`/auth/${mode}`, { method: "POST", body });
      setToken(access_token);
      nav(mode === "login" ? "/" : "/profile");
    } catch (e2) { setErr(e2.message); }
  };

  return (
    <div className="auth">
      <form onSubmit={submit} className="panel">
        <h1>{mode === "login" ? "Log in" : "Create your account"}</h1>
        {mode === "register" && (
          <label>Name<input value={f.name} onChange={set("name")} required minLength={2} /></label>
        )}
        <label>Email<input type="email" value={f.email} onChange={set("email")} required /></label>
        <label>Password<input type="password" value={f.password} onChange={set("password")} required minLength={8} /></label>
        {err && <p className="err" role="alert">{err}</p>}
        <button className="primary">{mode === "login" ? "Log in" : "Create account"}</button>
        <button type="button" className="link" onClick={() => setMode(mode === "login" ? "register" : "login")}>
          {mode === "login" ? "New here? Create an account" : "Have an account? Log in"}
        </button>
      </form>
    </div>
  );
}
